function Next=subbyte(S)

%subbyte.m
S_double=S;
S_gf=gf(S_double,8,'D^8+D^4+D^3+D+1');

S_inv_double=[];
for i=1:1:4
    for j=1:1:4
            ls=S_gf(i,j);
            if(ls.x==0)
                S_inv_double(i,j)=0;
            else
                temp=1/S_gf(i,j);
                S_inv_double(i,j)=temp.x;
            end
    end
end
S_inv_double;

str=dec2bin(S_inv_double,8);

S_inv_bin=[];
for i=1:1:16
    for j=1:1:8
        S_inv_bin(i,j)=str2num(str(i,j));
    end
end
S_inv_bin;
S_inv_bin_gf=gf(S_inv_bin,2);

X=[1 0 0 0 1 1 1 1;1 1 0 0 0 1 1 1;1 1 1 0 0 0 1 1;1 1 1 1 0 0 0 1;1 1 1 1 1 0 0 0;0 1 1 1 1 1 0 0;0 0 1 1 1 1 1 0;0 0 0 1 1 1 1 1];
X_gf=gf(X,2);
y=[1;1;0;0;0;1;1;0];
y_gf=gf(y,2);
N=[];
for i=1:1:16
    c=X_gf*reshape(S_inv_bin_gf(i,:),8,1);
    d=c+y_gf;
    t=reshape(d.x,1,8);
    byte_back=[];
    for j=1:1:8
        w=num2str(t(j));
        byte_back=[byte_back w];
    end
    byte_back_double=bin2dec(byte_back);
    N=[N byte_back_double];
end
%N is the 'next' state that is ready for next operation
N=reshape(N,4,4);
Next=N;



