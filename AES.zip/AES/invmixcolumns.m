%invmixcolumns.m
function N=invmixcolumns(S)
const_matx=[2 3 1 1;1 2 3 1;1 1 2 3;3 1 1 2];
const_matx_gf=gf(const_matx,8,'D^8+D^4+D^3+D+1');
const_matx_gf_inv=inv(const_matx_gf);
S_gf=gf(S,8,'D^8+D^4+D^3+D+1');
N_gf=gf([],8,'D^8+D^4+D^3+D+1');
for j=1:1:4
    N_gf(:,j)=const_matx_gf_inv*S_gf(:,j);
   
end
N_gf;

N=[];
for i=1:1:4
    for j=1:1:4
        temp=N_gf(i,j);
        N(i,j)=temp.x;
    end
end
