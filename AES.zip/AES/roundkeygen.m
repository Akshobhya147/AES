%roundkeygen.m
function roundkey_gf=roundkeygen(rno)
keystring='iamnoobaesisboon';
key=double(keystring);
key_gf=gf(key,8,'D^8+D^4+D^3+D+1');
w_gf=gf(zeros(44,4),8,'D^8+D^4+D^3+D+1');
w_gf(1,:)=[key_gf(1:4)];
w_gf(2,:)=[key_gf(5:8)];
w_gf(3,:)=[key_gf(9:12)];
w_gf(4,:)=[key_gf(13:16)];
for i=5:1:44
    if(mod(i-1,4)~=0)
        w_gf(i,:)=w_gf(i-1,:)+w_gf(i-4,:);
    else
        t=generatet(w_gf(i-1,:),rno);
        w_gf(i,:)=t+w_gf(i-4,:);
    end
end
roundkey_gf=[w_gf(4*rno+1:4*rno+4,:)];
