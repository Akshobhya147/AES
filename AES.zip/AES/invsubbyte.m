%invsubbyte.m
function Next=invsubbyte(S)

S_double=S;
S_gf=gf(S_double,8,'D^8+D^4+D^3+D+1');



str=dec2bin(S_double,8);

S_bin=[];
for i=1:1:16
    for j=1:1:8
        S_bin(i,j)=str2num(str(i,j));
    end
end
S_bin;
S_bin_gf=gf(S_bin,2);

X=[1 0 0 0 1 1 1 1;1 1 0 0 0 1 1 1;1 1 1 0 0 0 1 1;1 1 1 1 0 0 0 1;1 1 1 1 1 0 0 0;0 1 1 1 1 1 0 0;0 0 1 1 1 1 1 0;0 0 0 1 1 1 1 1];
X_gf=gf(X,2);
X_gf_inv=inv(X_gf);
y=[1;1;0;0;0;1;1;0];
y_gf=gf(y,2);
N=[];
for i=1:1:16
    d=reshape(S_bin_gf(i,:),8,1);
    c=d-y_gf;
    b=X_gf_inv*c;
    t=reshape(b.x,1,8);
    byte_back=[];
    for j=1:1:8
        w=num2str(t(j));
        byte_back=[byte_back w];
    end
    byte_back_double=bin2dec(byte_back);
    N=[N byte_back_double];
end
%N is the 'next' state that is ready for next operation
N=reshape(N,4,4);
N_gf=gf(N,8,'D^8+D^4+D^3+D+1');

N_inv_double=[];
for i=1:1:4
    for j=1:1:4
            ls=N_gf(i,j);
            if(ls.x==0)
                N_inv_double(i,j)=0;
            else
                temp=1/N_gf(i,j);
                N_inv_double(i,j)=temp.x;
            end
    end
end
N_inv_double;
Next=N_inv_double;



