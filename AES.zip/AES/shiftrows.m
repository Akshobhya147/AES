%shiftrows.m
function N=shiftrows(S)
for i=1:1:4
    S(i,:)=circshift(S(i,:),-1*(i-1));
end
N=S;
