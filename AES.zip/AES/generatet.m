%generatet.m
function t=generatet(w,rno)
rot=circshift(w,-1);

w_inv_double=[];
for i=1:1:4
    ls=rot(i);
    if(ls.x==0)
        w_inv_double(i)=0;
    else
        temp=1/rot(i);
        w_inv_double(i)=temp.x;
    end
end

w_inv_double;

str=dec2bin(w_inv_double,8);

w_inv_bin=[];
for i=1:1:4
    for j=1:1:8
        w_inv_bin(i,j)=str2num(str(i,j));
    end
end
w_inv_bin;
w_inv_bin_gf=gf(w_inv_bin,2);

X=[1 0 0 0 1 1 1 1;1 1 0 0 0 1 1 1;1 1 1 0 0 0 1 1;1 1 1 1 0 0 0 1;1 1 1 1 1 0 0 0;0 1 1 1 1 1 0 0;0 0 1 1 1 1 1 0;0 0 0 1 1 1 1 1];
X_gf=gf(X,2);
y=[1;1;0;0;0;1;1;0];
y_gf=gf(y,2);
N=[];
for i=1:1:4
    c=X_gf*reshape(w_inv_bin_gf(i,:),8,1);
    d=c+y_gf;
    g=reshape(d.x,1,8);
    byteback=[];
    for j=1:1:8
        b=num2str(g(j));
        byteback=[byteback b];
    end
    n=bin2dec(byteback);
    N=[N n];
end
sub=gf(N,8,'D^8+D^4+D^3+D+1');

switch rno
    case 1
        t=sub+gf([1 0 0 0],8,'D^8+D^4+D^3+D+1');
    case 2
        t=sub+gf([2 0 0 0],8,'D^8+D^4+D^3+D+1');
    case 3
        t=sub+gf([4 0 0 0],8,'D^8+D^4+D^3+D+1');
    case 4
        t=sub+gf([8 0 0 0],8,'D^8+D^4+D^3+D+1');
    case 5
        t=sub+gf([16 0 0 0],8,'D^8+D^4+D^3+D+1');
    case 6
        t=sub+gf([32 0 0 0],8,'D^8+D^4+D^3+D+1');
    case 7
        t=sub+gf([64 0 0 0],8,'D^8+D^4+D^3+D+1');
    case 8
        t=sub+gf([128 0 0 0],8,'D^8+D^4+D^3+D+1');
    case 9
        t=sub+gf([27 0 0 0],8,'D^8+D^4+D^3+D+1'); 
    case 10 
        t=sub+gf([54 0 0 0],8,'D^8+D^4+D^3+D+1');
    otherwise
        t=sub+gf([0 0 0 0],8,'D^8+D^4+D^3+D+1');
end





