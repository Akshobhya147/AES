%aes_128.m
%AES-128-(Original Design)
w = warning ('off','all');
clc;
clear all;
close all;
S=[];
plaintext=input('Enter plain-text(with element count 16):','s');
reshape(plaintext,4,4)
for j=1:1:4
    for i=1:1:4
        S(i,j)=double(plaintext((i+4*(j-1))));
    end
end

S_double=S;
S_double;
plaintext_double=S_double;
plaintext_double

%S_bin=dec2bin(hex2dec(S),8)
%S1=[];
%for i=1:1:16
%    for j=1:1:8
%        S1(i,j)=str2num(S_bin(i,j));
%    end
%end
%S1



%encryption
S_gf=gf(S_double,8,'D^8+D^4+D^3+D+1');
S_gf;
%pre-round transformation
roundkey=roundkeygen(0);
SS=gf([],8,'D^8+D^4+D^3+D+1');
for j=1:1:4
    SS(:,j)=S_gf(:,j)+reshape(roundkey(j,:),4,1);
end
SS;
SS_double=[];
for i=1:1:4
    for j=1:1:4
        temp=SS(i,j);
        SS_double(i,j)=temp.x;
    end
end
SS_double;

%10 rounds of AES-128
for round=1:1:10
    %sub-byte operation
    SS_double=subbyte(SS_double);
    %shift rows operation
    SS_double=shiftrows(SS_double);
    %mix columns operation
    if(round~=10)
        SS_double=mixcolumns(SS_double);
    end
    %adding round key
    SS=gf(SS_double,8,'D^8+D^4+D^3+D+1');
    roundkey=roundkeygen(round);
    C=gf([],8,'D^8+D^4+D^3+D+1');
    for j=1:1:4
        C(:,j)=SS(:,j)+reshape(roundkey(j,:),4,1);
    end
    C_double=[];
    for i=1:1:4
        for j=1:1:4
            temp=C(i,j);
            C_double(i,j)=temp.x;
        end
    end
    SS_double=C_double;
end

C_double=SS_double;
C_double
cipherstring=reshape(char(C_double),1,[]);
plaintext
cipherstring

%decrytpion
C=gf(C_double,8,'D^8+D^4+D^3+D+1');
C;
%pre-round transformation
roundkey=roundkeygen(10);
SS=gf([],8,'D^8+D^4+D^3+D+1');
for j=1:1:4
    SS(:,j)=C(:,j)+reshape(roundkey(j,:),4,1);
end
SS;
SS_double=[];
for i=1:1:4
    for j=1:1:4
        temp=SS(i,j);
        SS_double(i,j)=temp.x;
    end
end
SS_double;

%10 rounds of AES-128
for round=1:1:10
    %inverse shift rows operation
    SS_double=invshiftrows(SS_double);
    %inverse sub-byte operation
    SS_double=invsubbyte(SS_double);
    %adding round key
    SS=gf(SS_double,8,'D^8+D^4+D^3+D+1');
    roundkey=roundkeygen(10-round);
    C=gf([],8,'D^8+D^4+D^3+D+1');
    for j=1:1:4
        C(:,j)=SS(:,j)+reshape(roundkey(j,:),4,1);
    end
    C_double=[];
    for i=1:1:4
        for j=1:1:4
            temp=C(i,j);
            C_double(i,j)=temp.x;
        end
    end
    SS_double=C_double;
    %inverse mix columns operation
    if(round~=10)
        SS_double=invmixcolumns(SS_double);
    end
   
end

R_double=SS_double;
R_double
receivedstring=char(reshape(R_double,1,[]));
receivedstring
    



