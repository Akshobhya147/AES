%invshiftrows.m
function N=invshiftrows(S)
for i=1:1:4
    S(i,:)=circshift(S(i,:),(i-1));
end
N=S;
